from django.contrib import admin
from .models import Emprestimos

# Register your models here.
admin.site.register(Emprestimos)
