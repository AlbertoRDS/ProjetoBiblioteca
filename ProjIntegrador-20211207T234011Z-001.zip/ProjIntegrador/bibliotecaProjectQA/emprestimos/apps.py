from django.apps import AppConfig


class EmprestimosConfig(AppConfig):
    name = 'emprestimos'
