from django.apps import AppConfig


class AcervoConfig(AppConfig):
    name = 'acervo'
